# 氦氪模块硬件说明文档

## 1. 模块概述
Hekr V1.1 是由杭州氦氪科技有限公司开发的一款低功耗嵌入式 Wi-Fi 模块。这款模块搭载了一个高集成度、性价比极高的无线射频芯片 ESP8266EX，包含低功耗 32 位 CPU、2Mbyte flash 及 UART 通信接口，内置的 Wi-Fi 网络协议栈和丰富的库函数极大地缩短 Wi-Fi 设备的前期开发时间。

### 1.1 硬件构成框图
![](/images/3u1pav8.png)

### 1.2应用领域

* 智能家居
* 智慧建筑
* 工业互联
* 网络监控
* 智慧照明
* 传感云节点
* 可穿戴电子

### 1.3 模块特点

* 工作电压：3V ~ 3.6V
* 内置低功率 32 位 CPU：可以兼作应用处理器
* 板载 PCB 天线
* 支持 HekrConfig（一键配网）功能（包括Android和IOS设备）
* 内置 TCP/IP 协议栈
* 内置 10 bit 高精度 ADC
* 内置 UART串行接口
* 内置 多路GPIO
* 板载 PCB 天线
* 已通过 CE、FCC、RoHS 认证
* 待机状态消耗功率小于1.0mW (DTIM3)
* 工作温度范围 -40 ~ 85℃

## 2.模块参数

### 2.1主要参数

<table>
<tr><td rowspan="5">硬件参数</td><td>数据接口</td><td>UART、PWM、IIC、GPIO</td></tr>
<tr><td>工作电压</td><td>标准供电3.3V，可容忍±0.3V</td></tr>
<tr><td>工作电流</td><td>正常工作状态70mA，发射瞬间最大电流230mA</td></tr>
<tr><td>存储温度Ts</td><td>-40℃ ~ 125℃</td></tr>
<tr><td>最大焊接温度Tm</td><td>250℃</td></tr>
<tr><td  rowspan="5">软件参数</td><td>网络协议</td><td>	IPv4， TCP/UDP/HTTP/FTP</td></tr>

<tr><td>安全机制</td><td>WPA/WPA2</td></tr>
<tr><td>加密类型</td><td>WEP/TKIP/AES</td></tr>
<tr><td>升级固件</td><td>本地串口烧录、云端升级</td></tr>
</table>

### 2.2 尺寸参数

Hekr V1.1 Wi-Fi 模块外观尺寸为 21.87mm(L) x 14.06mm(W) x 3.00mm(H)，引脚间距为2mm（如下图所示）。

模组内采用的是 26MHz 晶振，使用 3dBi 的 PCB 板载天线。

![](/images/espsize.png)

### 2.3 引脚定义

模块引脚定义说明请参考下图：

![](http://docs.hekr.me/res/img/esppins.png)

| Pin | Name | Function |
----|----|----
| 1 | RST | 模块复位引脚 |
| 2 | 3V3 | 电源输入 |
| 3 | GND | 电源地 |
| 4 | SDA | IIC数据线，PWM输出，GPIO14输入输出。默认为Wi-Fi状态输出指示灯 |
| 5 | SCK | IIC时钟线，PWM输出，GPIO13输入输出，默认为一键配置引脚 |
| 6 | RXD | RXD 串口输入，GPIO3输入输出 |
| 7 | TXD | TXD 串口输出，GPIO1输入输出。注意：TXD上电时要拉高，不能拉低 |

### 2.4 工作参数

| 参数 | 描述 | 最小值 | 典型值 | 最大值 | 单位 |
------|-------|-------|----|----|----
| T | 工作温度 | -40 | - | 85 | ℃ |
| VDD | 工作电压 | 3.0 | - | 3.6 | V |
| Imax | IO驱动电流 | - | - | 12 | mA |
| Cpad | 输入引脚电容 | - | 2 | - | pF |
| VIL | IO口输入低电平 | -0.3 | - | 0.25VDD | V |
| VIH | IO口输入高电平 | 0.75VDD | - | 3.6 | V |
| VOL | IO口输出低电平 | - | - | 0.1VDD | V |
| VOH | IO口输出高电平 | 0.8VDD | - | - | V |

## 3. Wi-Fi 特性

### 3.1 基本射频特性

| 参数项 | 值 |
---|---
| 工作频率 | 2.400 ~ 2.500Ghz |
| 协议标准 | IEEE 802.11n/g/b(通道1-14) |
| 天线类型 | PCB 天线 |
| 11b | 2.412 ~ 2.472Ghz | 中心频率 |
| 11g | 2.412 ~ 2.472Ghz |
| 11n HT20 | 2.412 ~ 2.472Ghz |
| 11b | 1, 2, 5.5, 11 Mbps | 传输速率 |
| 11g | 6, 9, 12, 18, 24, 36, 48, 54 Mbps |
| 11n 1stream | MCS0，1, 2, 3, 4, 5, 6, 7 |
| 11b | DSSS | 调制类型 |
| 11g/n | OFDM |

### 3.2 Wi-Fi输出功率

| 参数项 | 值 |
---|---
| 802.11b CCK Mode （11M）平均输出功率 | +20dBm |
| 802.11g OFDM Mode （54M）平均输出功率 | +17dBm |
| 802.11n OFDM Mode （MCS7）平均输出功率 | +14dBm |

### 3.3 Wi-Fi接收灵敏度

| 参数项 | 值 |
---|---
| 802.11b CCK Mode （11M）灵敏度 | -91dBm |
| 802.11g OFDM Mode （54M）灵敏度 | -75dBm |
| 802.11n OFDM Mode （MCS7）灵敏度 | -72dBm |

### 3.4 Wi-Fi状态指示

模块上 LED 灯用来指示 Wi-Fi 连接状态，同时，为支持用户扩展，将 SDA（GPIO14）作为 Wi-Fi 状态指示引脚，便于用户外接 LED，其电平状态与板载 LED 指示灯同步。

1. 亮 1s、灭 1s：进入一键配置模式
2. 亮 2s、灭 2s：进入兼容配置模式
1. 亮 0.1s、灭 5s：已经登录上服务器（正常工作状态）
1. 亮 0.1s、灭 0.1s：尝试连接路由器
1. 亮 0.1s、灭 1s：尝试连接云端


## 4. 外围电路设计推荐

SCK（GPIO13）为一键配置引脚，需外接上拉电阻。

<strong>SCK 保持低电平3秒后拉高电平，模块会进入一键配置模式。注：模块同时清空了配置参数 SSID 和 password。</strong>


![](http://docs.hekr.me/res/img/espgpio.png)

### 4.1 应用说明
本模块适合于数据透传通信，简单类控制，如插座、LED 灯、传感器等。串口通信协议可根据厂家家电功能控制需求定制。

### 4.2 电路设计注意事项
* 如果需要使用 Wi-Fi 一键配置功能，设备必须有触发机制使氦氪 Wi-Fi 模块进入 Wi-Fi 配置模式。且需要有指示灯可以显示 Wi-Fi 配置的状态。参见`模块管脚功能定义`或者`透传协议-模块协议部分`。
* 电源输入端做好滤波处理，可添加 π 型滤波电路，另外可在模块电源输入端添加一个 47uF 的大电容，以满足芯片发射信号瞬间的电流需求。模块放置最好远离干扰源，如：变压器，电感，时钟线，晶振等。
* **在模块布局上应给模块天线留出一定的净空区域**，需要确保天线部分和其它金属器件距离至少 <strong>5mm</strong> 以上。下图中阴影部分标示区域需要远离金属器件、传感器、干扰源以及其它可能造成信号干扰的材料。天线无干扰区域最小距离如下图所示

![](http://docs.hekr.me/res/img/esplayout.png)

## 5. 仓储指南
### 5.1 存储条件
* 模块须存储在温度 < 40℃，湿度 < 85%RH 的环境中。
* 在生产全过程中，操作人员须做好静电防护措施。
* 操作时，严防模块沾水、污物及灰尘。

## 6. 附录

### 附1 模块资料下载

[Hekr_v1.1_Wi-Fi模块说明书及模块封装文件.zip](http://docs.hekr.me/res/file/hardware/HekrV1.1Wi-Fi模块说明书20151113.zip)

[Hekr_v1.1_Wi-Fi模块认证证书.zip](http://docs.hekr.me/res/file/hardware/认证证书.zip)


[WiFi模块使用说明](http://hekr-files.oss-cn-shanghai.aliyuncs.com/doc/WIFI%E6%A8%A1%E5%9D%97%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E.pdf)

### 附2 模块实物图片

![](http://docs.hekr.me/res/img/espphoto.png)

### 附3 模块 FCC 认证证书

![](http://docs.hekr.me/res/img/FCC.png)


>最新版文档请访问 [在线文档 http://docs.hekr.me](http://docs.hekr.me)
